3D Bold Navigation
=========

A bold navigation that slides in when active, replacing the current content in a 3D space.

[Article on CodyHouse](http://codyhouse.co/gem/3d-bold-navigation/)

[Demo](http://codyhouse.co/demo/3d-bold-navigation/index.html)

[Terms](http://codyhouse.co/terms/)

Icons from [Nucleo](http://nucleoapp.com/)
